<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Insects-butterfly2-flying around-24 frames-150x106" tilewidth="150" tileheight="106" tilecount="24" columns="24">
 <image source="EPIC RPG World Pack - Grass Land 2.0 v1.4/Props/Animated props/Insects-butterfly2-flying around-24 frames-150x106.png" width="3600" height="106"/>
</tileset>

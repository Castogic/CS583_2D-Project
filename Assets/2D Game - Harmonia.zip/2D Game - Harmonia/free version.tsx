<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="free version" tilewidth="32" tileheight="32" tilecount="20" columns="5">
 <image source="town free/town free/free version.png" width="176" height="144"/>
</tileset>

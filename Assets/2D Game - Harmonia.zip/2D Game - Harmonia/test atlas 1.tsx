<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="test atlas 1" tilewidth="64" tileheight="64" tilecount="880" columns="22">
 <image source="EPIC RPG World Pack - Grass Land 2.0 v1.4/Props/Static props/Atlas-Props-sheet1.png" width="1408" height="2560"/>
</tileset>
